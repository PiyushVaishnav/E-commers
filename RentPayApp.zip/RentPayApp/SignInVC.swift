//
//  LoginVC.swift
//  RentPayApp
//
//  Created by AkashMacMini on 9/15/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit
import Alamofire
class SignInVC: UIViewController, UITextFieldDelegate
{

    
    @IBOutlet weak var btnCleatText: UIButton!
    @IBOutlet weak var txtEmail: HoshiTextField!
    
    // for the user login detail
    var arrayUserContent = [AnyObject]()
    var arrayUserId = String()
    var arrayUserName = String()
    var arrayUserEmail = String()
    var arrayUserPassword = String()
    var arrayUserMassage = String()
    var arrayUserStatus = Int()
    
    // for the authentication
    
    var authorization = ApiAuthorization()
    
    @IBOutlet weak var txtPassword: HoshiTextField!
    @IBOutlet weak var btnSignIn: UIButton!
    
    @IBOutlet weak var btnCreateAccount: UIButton!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //self.btnCleatText.isHidden = true
        self.buttonShape()
    }
    
    func buttonShape()
    {
        
        //For Submit Button
        let submitRectShape = CAShapeLayer()
        submitRectShape.bounds = btnSignIn.frame
        submitRectShape.position = btnSignIn.center
        
        submitRectShape.path = UIBezierPath(roundedRect: btnSignIn.bounds, byRoundingCorners: [UIRectCorner.bottomLeft , UIRectCorner.topRight], cornerRadii: CGSize(width: 5, height: 5)).cgPath
        btnSignIn.layer.mask = submitRectShape
        
        //For CreatAccount Button
        let createRectShape = CAShapeLayer()
        createRectShape.bounds = btnCreateAccount.frame
        createRectShape.position = btnCreateAccount.center
        
        createRectShape.path = UIBezierPath(roundedRect: btnCreateAccount.bounds, byRoundingCorners: [UIRectCorner.bottomLeft , UIRectCorner.topRight], cornerRadii: CGSize(width: 5, height: 5)).cgPath
        btnCreateAccount.layer.mask = createRectShape
    
    }

    //set textbok border
    func textboxBorder()
    {
        
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor(hexString: "#74BD0D").cgColor
        border.frame = CGRect(x: 0, y: txtEmail.frame.size.height - width, width:  txtEmail.frame.size.width, height: txtEmail.frame.size.height)
        
        border.borderWidth = width
        txtEmail.layer.addSublayer(border)
        txtEmail.layer.masksToBounds = true
        
        let borderPassword = CALayer()
        let widthPassword = CGFloat(2.0)
        borderPassword.borderColor = UIColor(hexString: "#74BD0D").cgColor
        borderPassword.frame = CGRect(x: 0, y: txtPassword.frame.size.height - widthPassword, width:  txtPassword.frame.size.width, height: txtPassword.frame.size.height)
        
        borderPassword.borderWidth = widthPassword
        txtPassword.layer.addSublayer(borderPassword)
        txtPassword.layer.masksToBounds = true
        
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        if textField == txtEmail
        {
            txtPassword.becomeFirstResponder()
        }
        else if textField == txtPassword
        {
            txtPassword.resignFirstResponder()
        }
         return true
    }
    
    
    @IBAction func btnClearTextAction(_ sender: Any)
    {
        self.txtEmail.text = ""
        self.txtEmail.resignFirstResponder()
        //self.btnCleatText.isHidden = true
    }
    
    
    @IBAction func btnSecureEntry(_ sender: UIButton)
    {
        if sender.imageView?.image == UIImage(named: "closePassword")
        {
            let img = UIImage(named: "openPassword")
            sender.setImage(img, for: .normal)
            txtPassword.isSecureTextEntry = false
        }
        else
        {
            let img = UIImage(named: "closePassword")
            sender.setImage(img, for: .normal)
            txtPassword.isSecureTextEntry = true
        }
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btnBackAction(_ sender: UIBarButtonItem)
    {
        self.dismiss(animated: true, completion:nil);
        let main = UIStoryboard(name: "Main", bundle: nil)
        let home = main.instantiateViewController(withIdentifier: "HomeVC")
        self.revealViewController().pushFrontViewController(home, animated: true)
        

    }
    
    
    
    @IBAction func btnSignUpAction(_ sender: Any)
    {
        self.dismiss(animated: true, completion:nil);
        let main = UIStoryboard(name: "Main", bundle: nil)
        let home = main.instantiateViewController(withIdentifier: "SignUpVC")
        self.revealViewController().pushFrontViewController(home, animated: true)
      
    }
    
    
    // for the checking the textfields details 
    @IBAction func btnSignInAction(_ sender: Any)
    {
        
        self.arrayUserEmail = ""
        self.arrayUserPassword = ""
        
        if txtEmail.text != "" && txtPassword.text != ""
        {
            //call Function for post login data
            self.postLoginDetailData()
        }
        else
        {
            let altError = UIAlertController(title: "Alert", message: "Please enter correct Email_Id and Password!", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler:
            {
                (UIAlertAction) in
                self.txtEmail.becomeFirstResponder()
            })
            altError.addAction(okAction)
            self.present(altError, animated: true, completion: nil)
            
        }

    }
    

    // for the login user 
    //pass the login details
    func postLoginDetailData()
    {
            let url = URL(string: WebUrl.SIGNIN_URL)
        let headers = authorization.Authentication()
        
        let param = ["\(JsonFields.LOGIN_USER_EMAIL)":"\(txtEmail.text!)",
                     "\(JsonFields.LOGIN_USER_PASSWORD)":"\(txtPassword.text!)"]

        Alamofire.request(url!, method: .post, parameters: param, headers: headers).responseJSON
        {
            response in
            
            if(response.result.error == nil)
            {
                let result = response.result
                if let dict = result.value as? Dictionary<String,AnyObject>
                {
                    if let innerDict = dict["\(JsonFields.LOGIN_ARRAY)"]
                    {
                         self.arrayUserContent = innerDict as! [AnyObject]
                    }
                    if let logingStatus = dict["\(JsonFields.LOGIN_STATUS)"]
                    {
                        self.arrayUserStatus = logingStatus as! Int
                    }
                    if let loginMessage = dict["\(JsonFields.LOGIN_MESSAGE)"] {
                        self.arrayUserMassage = loginMessage as! String
                    }

                }
                
                UserDefaults.standard.set(self.arrayUserStatus, forKey: "status")
                UserDefaults.standard.set(self.arrayUserMassage, forKey: "msg")
                
                 print("Status \(self.arrayUserStatus) Message \(self.arrayUserMassage)")
                
                
                if self.arrayUserContent.count > 0
                {
                    for index in 0..<self.arrayUserContent.count
                    {
                        let data = self.arrayUserContent[index]
                        self.arrayUserId = data["\(JsonFields.LOGIN_USER_ID)"] as! String
                        self.arrayUserName = data["\(JsonFields.LOGIN_USER_NAME)"] as! String
                        self.arrayUserEmail = data["\(JsonFields.LOGIN_USER_EMAIL)"] as! String
                    }
                }

                if self.arrayUserStatus == 1
                {
                    self.view.makeToast("Login Success", duration: 1.0, position: .bottom)
                    
                    let alert = UIAlertController(title: "Success.",message: "Login Successfull.", preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "ok", style: .default)
                    {
                        (UIAlertAction) in
                        
                        //self.appDelegate?.loginLogout = true
                        UserDefaults.standard.set(self.arrayUserName, forKey: "name")
                        UserDefaults.standard.set(self.arrayUserId , forKey: "id")
                        //UserDefaults.standard.set(self.loginCustomerMobile, forKey: "mobile")
                        UserDefaults.standard.set(self.arrayUserEmail, forKey: "email")
                        //kConstantObj.SetIntialMainViewController("HomeVC")
                        let main = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC")
                        self.present(main, animated: true, completion: nil)
                    }
                    
                    alert.addAction(okAction)
                    self.present(alert, animated: true, completion: nil)
                    
                }
                else if self.arrayUserStatus == 0
                {
                    //self.appDelegate?.loginLogout = false
                    self.view.makeToast("Login Faild!", duration: 1.0, position: .bottom)
                    let alert = UIAlertController(title: "Alert",message: "Login Fail.", preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "ok", style: .default)
                    
                    alert.addAction(okAction)
                    self.present(alert, animated: true, completion: nil)
                    self.txtEmail.becomeFirstResponder()
                }
            }else
            {print(response.result.error!)
            }
        }
}
}
