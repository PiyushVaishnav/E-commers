//
//  HomeVC.swift
//  RentPayApp
//
//  Created by AkashMacMini on 9/13/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit
import Alamofire
class HomeVC: UIViewController, UIScrollViewDelegate, UICollectionViewDelegate, UICollectionViewDataSource
{

    @IBOutlet weak var collectionView: UICollectionView!
    var catid = Int()
    var cat_id = String()
    //collectionview
    var arrayCategoryContent = [AnyObject]()
    var arrayCategoryStatus = Int()
    var arrayCategoryId = [String]()
    var arrayCategoryName = [String]()
    var arrayCategoryImage = [String]()
    //var arrayCategoryImageUrl = [String]()

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var page: UIPageControl!
    //menu Button
    @IBOutlet weak var menu: UIBarButtonItem!
    
    //for the slider
    var arraySliderContent = [AnyObject]()
    var arraySliderID = [String]()
    var arraySliderImage = [String]()
    var sliderStatus = Int()

    //for authorization
    var authorization = ApiAuthorization()
    
    var img = [String]()
    var frame = CGRect(x: 0, y: 0, width: 0, height: 0)
    var imageView = UIImageView()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // for the side menu
        if revealViewController() != nil
        {
            menu.target = self.revealViewController()
            menu.action = #selector(SWRevealViewController.revealToggle(_:))
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            self.view.addGestureRecognizer(revealViewController().tapGestureRecognizer())
        }
        print("menu clicked\(menu)")
       
        //get the collectionview data
        self.getCollectionViewData()
        
        //for the get data
        self.getSliderData()
        
       UIApplication.shared.statusBarStyle = .lightContent
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    func getSliderData()
    {
        let url = URL(string: WebUrl.SLIDER_URL)
        let headers = authorization.Authentication()
        
        Alamofire.request(url!, method: .post, headers: headers).responseJSON{
            response in
            
            if (response.result.error == nil)
            {
                let result  = response.result
                //give the format for storing data
                if let dict = result.value as? Dictionary<String, AnyObject>
                {
                    //give the location of array to store the value
                    if let innerdict = dict["\(JsonFields.SLIDER_ARRAY)"]
                    {
                        //any object store the all format value
                        self.arraySliderContent = innerdict as! [AnyObject]
                        
                    }
                }
                
                //check slide content
                
                if self.arraySliderContent.count > 0
                {
                    for index in 0..<self.arraySliderContent.count
                    {
                        let data = self.arraySliderContent[index]
                        self.arraySliderID.append(data["\(JsonFields.SLIDER_ID)"] as! String)
                        //append the images
                        self.arraySliderImage.append("\(WebUrl.SLIDER_IMAGE_URL)\(data["\(JsonFields.SLIDER_IMAGES)"] as! String)")
                        
                    }
                    //call show slider funtion
                    print("Slider Images \(self.arraySliderImage)")
                    self.showSlider()
                    
                }
                
                
            }
        }
    }

    
    //for the slider
    func showSlider()
    {
        
        page.numberOfPages = arraySliderImage.count
        
        for index in 0..<arraySliderImage.count
        {
            frame.origin.x = scrollView.frame.size.width * CGFloat(index)
            frame.size = scrollView.frame.size
            
            imageView = UIImageView(frame: frame)
            
            if let imageUrl = URL(string: arraySliderImage[index])
            {
                if let data = NSData(contentsOf: imageUrl)
                {
                    if data != nil
                    {
                        imageView.image = UIImage(data: data as Data)
                        
                    }
                    else{
                        print("Error in ImageView")
                    }
                    
                }
                
            }
            
            self.scrollView.addSubview(imageView)
            
        }
        scrollView.contentSize = CGSize(width: (scrollView.frame.size.width * CGFloat(arraySliderImage.count)), height: scrollView.frame.size.height)
        
        scrollView.delegate = self
        
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
    {
        
        let pageNumber = scrollView.contentOffset.x / scrollView.frame.size.width
        
        page.currentPage = Int(pageNumber)
        
        print(Int(pageNumber))
        
    }

    func getCollectionViewData()
    {
        
        let url = URL(string: WebUrl.CATEGORY_LIST)
        let headers = authorization.Authentication()
        
        Alamofire.request(url!, method: .post, headers: headers).responseJSON
        {
            response in
            
            if (response.result.error == nil)
            {
                let result = response.result
                if let dict = result.value as? Dictionary<String,AnyObject>
                {
                    if let innerDict = dict["\(JsonFields.CATEGORY_LIST_ARRAY)"]
                    {
                        self.arrayCategoryContent = innerDict as! [AnyObject]
                    }
                    if let innerStatus = dict["\(JsonFields.CATEGORY_LIST_STATUS)"]
                    {
                        self.arrayCategoryStatus = innerStatus as! Int
                    }
                }
                
                if self.arrayCategoryContent.count > 0
                {
                    for index in 0..<self.arrayCategoryContent.count
                    {
                        let data = self.arrayCategoryContent[index]
                        
                        self.arrayCategoryId.append(data["\(JsonFields.CATEGORY_LIST_ID)"] as! String)
                        self.arrayCategoryName.append(data["\(JsonFields.CATEGORY_LIST_NAME)"] as! String)
                    
                        
                        //append the images
                        self.arrayCategoryImage.append("\(WebUrl.CATEGORY_IMAGE_URL)\(data["\(JsonFields.CATEGORY_LIST_IMAGE)"] as! String)")
                        
                    }
                }
                print("category id := \(self.arrayCategoryId)")
                self.collectionView.reloadData()
                
            }
            else{print(response.result.error!)}
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return arrayCategoryName.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeCell", for: indexPath) as! HomeCollectionViewCell

        cell.lblTitleName.text = arrayCategoryName[indexPath.row]
        
        if let imageUrl = URL(string: (arrayCategoryImage[indexPath.row]))
        {
            print("image data",imageUrl)
            
            if let data =  NSData(contentsOf: imageUrl)
            {
                if data != nil
                {
                    cell.CollectionViewCell.image = UIImage(data: data as Data)
                }
                else{print("error in imageview")}
            }
        }
        
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        collectionView.deselectItem(at: indexPath, animated: true)
        let subCat = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailsVC") as! DetailsVC
        //subCat.arrayCategoryId = [self.arrayCategoryId[indexPath.row]]
        //self.navigationController?.pushViewController(subCat, animated: true)
        //subCat.arrayCategoryListId = [arrayCategoryId[indexPath.row]]
        subCat.cat_id = arrayCategoryId[indexPath.row]
        
        print("Category ID : \(cat_id)")
        self.present(subCat, animated: true, completion: nil)

    }
    
    @IBAction func btnPostAction(_ sender: UIBarButtonItem)
    {
        let main = UIStoryboard(name: "Main", bundle: nil)
        let home = main.instantiateViewController(withIdentifier: "PostProductVC")
        //self.revealViewController().pushFrontViewController(home, animated: true)
        self.present(home, animated: true, completion: nil)
        
        
    }
    

}
