//
//  HomeCollectionViewCell.swift
//  RentPayApp
//
//  Created by AkashMacMini on 9/14/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell
{
    
    @IBOutlet weak var CollectionViewCell: UIImageView!
    
    @IBOutlet weak var lblTitleName: UILabel!
    
}
