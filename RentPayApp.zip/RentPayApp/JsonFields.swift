//
//  JsonFields.swift
//  Quotes And Status
//
//  Created by Akash Padhiyar on 7/14/17.
//  Copyright © 2017 com.awesomeinfotech. All rights reserved.
//

import Foundation
class JsonFields {
    
     static var AUTHORIZATION_KEY = "Authorization"
     static var SUCCESS = "status"
    
    //SLIDER FIELDS
    static var SLIDER_ARRAY = "slider"
    static var SLIDER_IMAGES = "slider_image"
    static var SLIDER_ID = "slider_id"
    
    //CATEGORY LIST FIELDS
    static var CATEGORY_LIST_ARRAY = "category"
    static var CATEGORY_LIST_ID = "cat_id"
    static var CATEGORY_LIST_NAME = "cat_name"
    static var CATEGORY_LIST_IMAGE = "cat_img"
    static var CATEGORY_LIST_STATUS = "status"
      
    //CATEGORY_IMAGE_FIELDS
    static var CATEGORY_IMAGE_ARRAY = "category"
    static var CATEGORY_IMAGE_URL = "cat_img"

    //SIGN UP FIELDS
    static var USER_NAME = "user_name"
    static var USER_EMAIL = "user_email"
    static var USER_PASSWORD = "user_password"
    static var USER_IP = "ip_address"
    static var USER_STATUS = "status"
    
    //LOGIN POST FIELD
    static var LOGIN_USER_EMAIL = "user_email"
    static var LOGIN_USER_PASSWORD = "user_password"
    static var LOGIN_STATUS = "status"
    static var LOGIN_MESSAGE = "msg"
    static var LOGIN_ARRAY = "user"
    static var LOGIN_USER_ID = "user_id"
    static var LOGIN_USER_NAME = "user_name"
    
    //FAQ FIELDS
    static var FAQ_ARRAY = "faq"
    static var FAQ_ID = "faq_id"
    static var FAQ_QUESTION = "faq_question"
    static var FAQ_ANSWER = "faq_answer"
    static var FAQ_IS_ACTIVE = "is_active"

    //PRODUCTS FIELDS
    static var CATEGORY_DETAIL_STATUS = "status"
    static var CATEGORY_DETAIL_ARRAY = "products"
    static var CATEGORY_DETAIL_ID = "product_id"
    static var CATEGORY_DETAIL_NAME = "product_title"
    static var CATEGORY_DETAIL_DESCRIPTION = "product_desc"
    static var CATEGORY_DETAIL_RENT = "rent_amount"
   
    static var CATEGORY_DETAIL_IMAGE_ARRAY = "product_images"
    static var CATEGORY_DETAIL_IMAGE = "product_thumb"
    
    
    //PRODUCT DESCRIPTIONS
    static var DESCRIPT_STATUS = "status"
    static var DESCRIPT_ARRAY = "product_details"
   
    static var DESCRIPT_ID = "product_id"
    static var DESCRIPT_PRICE = "rent_amount"
    static var DESCRIPT_QUANTITY = "quantity"
    static var DESCRIPT_DESCRIPTIONS = "product_desc"

    static var DESCRIPT_IMAGE_ARRAY = "product_images"
    static var DESCRIPT_IMAGE = "product_image"
    
    //POST FIELDS
    static var POST_TITLE = "product_title"
    static var POST_DESC = "product_desc"
    static var POST_CATEGORY = "cat_id"
    static var POST_SUB_CAT = "sub_cat_id"
    static var POST_QUANTITY = "quantity"
    static var POST_MOBILE = "phone"
    static var POST_CONDITION = "product_condition"
    static var POST_BRAND_NAME = "brand_name"
    static var POST_RENT_AMOUNT = "rent_amount"
    static var POST_SECURITY_AMOUNT = "security_deposit"
    
    static var POSR_STATUS = "status"
    

}
