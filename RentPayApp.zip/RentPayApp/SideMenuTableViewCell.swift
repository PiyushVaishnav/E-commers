//
//  SideMenuTableViewCell.swift
//  RentPayApp
//
//  Created by AkashMacMini on 9/13/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit

class SideMenuTableViewCell: UITableViewCell
{

    @IBOutlet weak var sideMenuImage: UIImageView!
    
    @IBOutlet weak var sideMenuText: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
