//
//  SideMenu.swift
//  RentPayApp
//
//  Created by AkashMacMini on 9/13/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit

class SideMenu: UIViewController, UITabBarDelegate, UITableViewDataSource, UITableViewDelegate
{

    @IBOutlet weak var sideMenuTableView: UITableView!
    var arrayName = [String]()
    var arrayImage = [String]()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //for the hide the extra cell
        arrayName =  ["Login","About Us","Contact Us","FAQ","Rate Us","Share"]
        arrayImage = ["Login","About Us","Contact Us","FAQ","Rate Us","Share"]
 
        self.sideMenuTableView.tableFooterView = UIView()
        //UIApplication.shared.statusBarStyle = .lightContent
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        //this one is return the no of row count
        return arrayName.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuCell")as! SideMenuTableViewCell
        cell.sideMenuText.text = arrayName[indexPath.row]
        cell.sideMenuImage.image = UIImage(named: arrayImage[indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if arrayName[indexPath.row] == "Login"
        {
            let main = UIStoryboard(name: "Main", bundle: nil)
            let login = main.instantiateViewController(withIdentifier: "SignInVC") as! SignInVC
            self.revealViewController().pushFrontViewController(login, animated: true)
        }
        else if arrayName[indexPath.row] == "About Us"
        {
            let main = UIStoryboard(name: "Main", bundle: nil)
            let login = main.instantiateViewController(withIdentifier: "AboutUsVC") as! AboutUsVC
            self.revealViewController().pushFrontViewController(login, animated: true)
        }
        else if arrayName[indexPath.row] == "Contact Us"
        {
            let main = UIStoryboard(name: "Main", bundle: nil)
            let login = main.instantiateViewController(withIdentifier: "ContactUsVC") as! ContactUsVC
            self.revealViewController().pushFrontViewController(login, animated: true)
        }
        else if arrayName[indexPath.row] == "FAQ"
        {
            let main = UIStoryboard(name: "Main", bundle: nil)
            let login = main.instantiateViewController(withIdentifier: "FAQVC") as! FAQVC
            self.revealViewController().pushFrontViewController(login, animated: true)
        }
        else if arrayName[indexPath.row] == "Rate Us"
        {
            let url = URL(string: "itms-apps://itunes.apple.com/us/app/id1169453499")
            UIApplication.shared.openURL(url!)
        }
        else if arrayName[indexPath.row] == "Share"
        {
            let vc = UIActivityViewController(activityItems: ["Download Akash Padhiyar iOS App : itms-apps://itunes.apple.com/us/app/id1169453499"], applicationActivities: nil)
            vc.popoverPresentationController?.sourceView = self.view
            vc.excludedActivityTypes = [ UIActivityType.airDrop, UIActivityType.postToFacebook,UIActivityType.postToTwitter]
            self.present(vc, animated: true, completion: nil)
        }
        
    }
    
}
