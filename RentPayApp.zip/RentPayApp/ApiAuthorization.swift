//
//  ApiAuthorization.swift
//  Quotes And Status
//
//  Created by Akash Padhiyar on 7/14/17.
//  Copyright © 2017 com.awesomeinfotech. All rights reserved.
//

import Foundation

class ApiAuthorization
{
        //this one for the authenticate use id password
        func Authentication() -> [String : String]
        {
            let username = "rentpay"
            let password = "rentpay@999"
            let loginString = String(format: "%@:%@", username, password)
            let loginData = loginString.data(using: String.Encoding.utf8)!
            let base64LoginString = loginData.base64EncodedString()
            let headers = ["Authorization": "Basic \(base64LoginString)"]
        
            return headers
        }
}
