//
//  DescriptionVC.swift
//  RentPayApp
//
//  Created by Akash Technolabs on 06/10/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit
import Alamofire
class DescriptionVC: UIViewController, UIScrollViewDelegate
{
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var page: UIPageControl!
    @IBOutlet weak var btnContact: UIButton!
    
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var lblQuantity: UILabel!
    @IBOutlet weak var lblDescripton: UILabel!
    
    //for the json object
    var arrayDescript = String()
    var arrayDescriptID = String()
    var arrayDescriptPrice = String()
    var arrayDescriptQuantity = String()
    var arrayDescriptDescription = String()
    
    //for the images of description details
    var arrayDescriptImage = [AnyObject]()
    var arrayDescriptImagaUrl = [String]()
    
    //for the passing data
    var cat_id1 = String()
    var back_id = String()
    var innerStatus = 0
    
    //ARRAY OBJECT FOR THE SET THE JSON
    var arrayDescriptContent = [AnyObject]()
    var arrayDescriptStatus = Int()

    var authentication  = ApiAuthorization()
    
    var img = [String]()
    var frame = CGRect(x: 0, y: 0, width: 0, height: 0)
    var imageView = UIImageView()
    
    
    @IBAction func btnContactSellerAction(_ sender: UIButton)
    {
        let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ContactSellerVC") as! ContactSellerVC
        dest.back_id = "\(self.cat_id1)"

     self.present(dest, animated: true, completion: nil)
        
    }
   
    
    override func viewDidLoad()
    {
        
        
        self.scrollView.layer.cornerRadius = 5
        scrollView.layer.masksToBounds = false
        scrollView.clipsToBounds = true
        super.viewDidLoad()
        self.ButtonShape()
        self.getProductData()
        
        
    }
    
    func ButtonShape()
    {
        //For CreatAccount Button
        let createRectShape = CAShapeLayer()
        createRectShape.bounds = btnContact.frame
        createRectShape.position = btnContact.center
        createRectShape.path = UIBezierPath(roundedRect: btnContact.bounds, byRoundingCorners: [UIRectCorner.bottomLeft , UIRectCorner.topRight], cornerRadii: CGSize(width: 5, height: 5)).cgPath
        btnContact.layer.mask = createRectShape
    }
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getProductData()
    {
        let url = URL(string: WebUrl.DESCRIPTIONS_URL)
        
        let params = ["\(JsonFields.DESCRIPT_ID)":"\(self.back_id)"]
        print("PARAMS\(params)")
        let headers = authentication.Authentication()

        Alamofire.request(url!, method: .post, parameters: params, headers: headers).responseJSON
            {
                response in
                
                if (response.result.error == nil)
                {
                    let result = response.result
                    
                    if let dict = result.value as? Dictionary<String,AnyObject>
                    {
                        self.innerStatus = dict["\(JsonFields.DESCRIPT_STATUS)"] as! Int
                    
                        if self.innerStatus == 1
                        {
                            
                            if let innerDict = dict["\(JsonFields.DESCRIPT_ARRAY)"]
                            {
                                print("Result1 : \(innerDict)")
                                self.arrayDescriptContent = innerDict as! [AnyObject]
                            }
                            
                            for index in 0..<self.arrayDescriptContent.count
                            {
                                let data = self.arrayDescriptContent[index]
                                
                                print("Result3 : \(data)")
                                self.arrayDescriptID.append(data["\(JsonFields.DESCRIPT_ID)"] as! String)
                                self.arrayDescriptPrice.append(data["\(JsonFields.DESCRIPT_PRICE)"] as! String)
                                self.arrayDescriptQuantity.append(data["\(JsonFields.DESCRIPT_QUANTITY)"] as! String)
                                self.arrayDescriptDescription.append(data["\(JsonFields.DESCRIPT_DESCRIPTIONS)"] as! String)
                                
                                self.lblPrice.text = "\(self.arrayDescriptPrice)"
                                self.lblQuantity.text = "\(self.arrayDescriptQuantity)"
                                //removing html tag
                                let content = self.arrayDescriptDescription
                                
                                self.arrayDescriptDescription = content.replacingOccurrences(of: "<[^>]+>", with: "", options: String.CompareOptions.regularExpression, range: nil)
                                self.lblDescripton.text = "\(self.arrayDescriptDescription)"
                                
                                
                                
                                print("PRODUCT\(self.arrayDescriptID)-\(self.arrayDescriptPrice)-\(self.arrayDescriptQuantity)-\(self.arrayDescriptDescription)")
                                
                                //for the checking the image
                                
                                if let innerImageDict = data["\(JsonFields.DESCRIPT_IMAGE_ARRAY)"]
                                {
                                    //print("ImageURL : \(innerImageDict)")
                                    self.arrayDescriptImage = innerImageDict as! [AnyObject]
                                    
                                    if self.arrayDescriptImage.count > 0
                                    {
                                        for image in 0..<self.arrayDescriptImage.count
                                        {
                                            
                                            let imageData = self.arrayDescriptImage[image]
                                            print("ImageURL \(imageData["\(JsonFields.DESCRIPT_IMAGE)"])")
                                            
                                            self.arrayDescriptImagaUrl.append("\(WebUrl.PRODUCT_IMAGE_URL)\(imageData["\(JsonFields.DESCRIPT_IMAGE)"] as! String )")
                                        }
                                    
                                    }
                                    self.showSlider()
                                }
                                
                            }
                        }
                        else
                        {print(Error.self)
                        }
                        print("DES category id := \(self.arrayDescriptID)")
                        }
                }else{print(response.result.error!)}
        }
    }
    
    //for the slider
    func showSlider()
    {
        
        page.numberOfPages = arrayDescriptImagaUrl.count
        print("IMAGE_URL\(arrayDescriptImagaUrl.count)")
        
        for index in 0..<arrayDescriptImagaUrl.count
        {
            frame.origin.x = scrollView.frame.size.width * CGFloat(index)
            frame.size = scrollView.frame.size
            imageView = UIImageView(frame: frame)
            
            if let imageUrl = URL(string: arrayDescriptImagaUrl[index])
            {
                if let data = NSData(contentsOf: imageUrl)
                {
                    if data != nil
                    {
                        imageView.image = UIImage(data: data as Data)
                    }
                    else{
                        print("Error in ImageView")
                    }
                }
                
            }
            
            self.scrollView.addSubview(imageView)
            
        }
        scrollView.contentSize = CGSize(width: (scrollView.frame.size.width * CGFloat(arrayDescriptImagaUrl.count)), height: scrollView.frame.size.height)
        
        scrollView.delegate = self
        
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
    {
        
        let pageNumber = scrollView.contentOffset.x / scrollView.frame.size.width
        page.currentPage = Int(pageNumber)
        print(Int(pageNumber))
        
    }
    @IBAction func btnBakcAction(_ sender: Any)
    {
        let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailsVC") as! DetailsVC
        dest.cat_id = "\(self.cat_id1)"
    
       self.dismiss(animated: true, completion:nil)
       //self.revealViewController().pushFrontViewController(dest, animated: true)
       
       
       //self.present(dest, animated: true, completion: nil)

//        
//        let sb = UIStoryboard(name: "Main", bundle: nil)
//        let controller = sb.instantiateViewController(withIdentifier: "DetailsVC")
//        
//        let nc = revealViewController().frontViewController as! UINavigationController
//        nc.pushViewController(controller, animated: false)
//        revealViewController().pushFrontViewController(nc, animated: true)
        
        
    }
    
}
