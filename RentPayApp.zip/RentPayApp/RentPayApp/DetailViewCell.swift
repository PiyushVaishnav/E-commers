//
//  DetailViewCell.swift
//  RentPayApp
//
//  Created by Akash Technolabs on 03/10/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit

class DetailViewCell: UITableViewCell
{

    //outlets for the details cell
    
    
    @IBOutlet weak var detail_ImageView: UIImageView!
    
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var lblPrice: UILabel!
    
    @IBOutlet weak var lblDetails: UILabel!
    
    
    
    @IBOutlet weak var uiView: UIView!
    
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        
        //self.uiView.layer.borderColor = UIColor(hexString: "#E0200C") as! CGColor
        self.uiView.layer.cornerRadius = 13
        
        //detail_ImageView.layer.borderWidth=1.0
        detail_ImageView.layer.masksToBounds = false
        //detail_ImageView.layer.borderColor = UIColor.white.cgColor
        //detail_ImageView.layer.cornerRadius = 13
        detail_ImageView.clipsToBounds = true
        //self.imageView?.layer.borderColor = (UIColor(hexString: "#E0200C") as! CGColor)
        // Initialization code
        detail_ImageView.layer.cornerRadius = detail_ImageView.frame.height / 2
        uiView.layer.cornerRadius = uiView.frame.height / 2
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
