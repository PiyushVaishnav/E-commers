//
//  Toast-Swift-Framework.h
//  Toast-Swift-Framework
//
//  Created by Sandro Machado on 14/04/16.
//  Copyright © 2016 Charles Scalesse. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Toast-Swift-Framework.
FOUNDATION_EXPORT double Toast_Swift_FrameworkVersionNumber;

//! Project version string for Toast-Swift-Framework.
FOUNDATION_EXPORT const unsigned char Toast_Swift_FrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Toast_Swift_Framework/PublicHeader.h>


