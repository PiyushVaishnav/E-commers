//
//  FAQVC.swift
//  RentPayApp
//
//  Created by Akash Technolabs on 02/10/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit
import Alamofire

class FAQVC: UIViewController, UITableViewDataSource, UITableViewDelegate
{

    @IBOutlet weak var faqTableView: UITableView!
    //for the counting
    var selectedIndex = -1
    
    //for the get data in json array
    var arrayFAQContent = [AnyObject]()
    var arrayFAQId = [String]()
    var arrayFAQ_Quetion = [String]()
    var arrayFAQAnswer = [String]()
    var arrayIsActive = [String]()
    
    // for the authentication 
    var authentication = ApiAuthorization()
    
    @IBAction func btnBakcAction(_ sender: Any)
    {
        let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC")
        self.revealViewController().pushFrontViewController(dest, animated: true)
    }
    
    func getFAQ_Data()
    {
        
        let url = URL(string: WebUrl.FAQ_URL)
        
        let headers = authentication.Authentication()
    
        Alamofire.request(url!, method: .post, headers: headers).responseJSON
        {
            response in
        
            if (response.result.error == nil)
            {
                let result = response.result
                //set the json array
                if let dict = result.value as? Dictionary<String,AnyObject>
                {
                    if let innerDict = dict["\(JsonFields.FAQ_ARRAY)"]
                    {
                        self.arrayFAQContent = innerDict as! [AnyObject]
                    }
                }
                
                //print("Array \(self.arrayContent)")
                
                if self.arrayFAQContent.count > 0
                {
                    for index in 0..<self.arrayFAQContent.count
                    {
                        let data = self.arrayFAQContent[index]
                        
                        self.arrayFAQId.append(data["\(JsonFields.FAQ_ID)"] as! String)
                        self.arrayFAQ_Quetion.append(data["\(JsonFields.FAQ_QUESTION)"] as! String)
                        self.arrayFAQAnswer.append(data["\(JsonFields.FAQ_ANSWER)"] as! String)
                        self.arrayIsActive.append(data["\(JsonFields.FAQ_IS_ACTIVE)"] as! String)
                    }
                }
                //print the array quetions
                print("FAQ \(self.arrayFAQAnswer)")
                self.faqTableView.reloadData()
//for the get the error
            }else{print(response.result.error!)}
        }
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayFAQId.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if selectedIndex == indexPath.row
        {return 220
        }
        else
        {return 58
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if selectedIndex == indexPath.row {
            selectedIndex = -1
        }else {
            selectedIndex = indexPath.row
        }
        
        self.faqTableView.beginUpdates()
        self.faqTableView.reloadRows(at: [indexPath], with: .automatic)
        self.faqTableView.endUpdates()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FaqCell", for: indexPath) as! FAQTableCell
        
        cell.lblIndex.text = "\(indexPath.row + 1)."
        cell.lblQuestion.text = "\(self.arrayFAQ_Quetion[indexPath.row])"
        cell.txtAnswer.text = self.arrayFAQAnswer[indexPath.row]
        
        //self.activityLoader.stopAnimating()
        //self.activityLoader.hidesWhenStopped = true
        
        return cell
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // call the getdata fuction
        self.getFAQ_Data()
        
        self.faqTableView.tableFooterView = UIView()
        
        // Do any additional setup after loading the view.
    }

    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
