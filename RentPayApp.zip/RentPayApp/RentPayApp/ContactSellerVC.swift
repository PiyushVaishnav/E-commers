//
//  ContactSellerVC.swift
//  RentPayApp
//
//  Created by Akash Technolabs on 07/10/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit

class ContactSellerVC: UIViewController {

    
    @IBOutlet weak var btnSubmitAction: UIButton!
    
    @IBOutlet weak var txtName: HoshiTextField!
    @IBOutlet weak var txtEmail: HoshiTextField!
    @IBOutlet weak var txtPhone: HoshiTextField!
    @IBOutlet weak var txtMessage: HoshiTextField!
    
    var back_id = String()
     
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.ButtonShape()
        
        // Do any additional setup after loading the view.
    }

    func ButtonShape()
    {
        //For Button Shape
        let createRectShape = CAShapeLayer()
        createRectShape.bounds = btnSubmitAction.frame
        createRectShape.position = btnSubmitAction.center
        createRectShape.path = UIBezierPath(roundedRect: btnSubmitAction.bounds, byRoundingCorners: [UIRectCorner.bottomLeft , UIRectCorner.topRight], cornerRadii: CGSize(width: 5, height: 5)).cgPath
        btnSubmitAction.layer.mask = createRectShape
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btnBack(_ sender: UIBarButtonItem)
    {
        self.dismiss(animated: true, completion:nil);
        let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DescriptionVC") as! DescriptionVC
        //self.revealViewController().pushFrontViewController(dest, animated: true)
        dest.cat_id1 = "\(self.back_id)"
        self.present(dest, animated: true, completion: nil)

    }
    
    
}
