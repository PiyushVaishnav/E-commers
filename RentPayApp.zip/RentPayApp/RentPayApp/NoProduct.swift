//
//  NoProduct.swift
//  RentPayApp
//
//  Created by Akash Technolabs on 06/10/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit

class NoProduct: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btnBakcAction(_ sender: Any)
    {
      // let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailsVC")
     //self.revealViewController().pushFrontViewController(dest, animated: true)
        
        self.dismiss(animated: true, completion:nil);

        let main = UIStoryboard(name: "Main", bundle: nil)
        let training = main.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        //self.revealViewController().pushFrontViewController(training, animated: true)
        self.present(training, animated: true, completion: nil)
    }
    
    
   

}
