//
//  PostProductVC.swift
//  RentPayApp
//
//  Created by Akash Technolabs on 03/10/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit
import Alamofire
class PostProductVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource
{
    
     var pickerView = UIPickerView()
    
    //outelet for the geting data
    @IBOutlet weak var txtTitle: HoshiTextField!
    @IBOutlet weak var txtDescription: HoshiTextField!
    @IBOutlet weak var txtMobile: HoshiTextField!
    @IBOutlet weak var txtProductCondition: HoshiTextField!
    @IBOutlet weak var txtBrandName: HoshiTextField!
    @IBOutlet weak var txtRentAmount: HoshiTextField!
    @IBOutlet weak var txtSecurityAmount: HoshiTextField!
    @IBOutlet weak var txtSubCategory: UITextField!
    @IBOutlet weak var txtCategory: UITextField!
    @IBOutlet weak var lblQuantity: UILabel!
    
    
    // for the set the json object
    var arrayTitle = String()
    var arrayDesc = String()
    var arrayCategory = [String]()
    var arraySubCat = [String]()
    var arrayQuantity = String()
    var arrayCondition = [String]()
    var arrayMobile = String()
    var arrayBrandName = String()
    var arrayRentAmount = String()
    var arraySecurityAmount = String()
    
    var arrayContent = [AnyObject]()
    var arrayStatus = Int()
    
    //for the  authentication
    var authenticaton = ApiAuthorization()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func dismissKeybord()
    {
        txtCategory.resignFirstResponder()
        txtSubCategory.resignFirstResponder()
        txtMobile.resignFirstResponder()
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return arrayCategory.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        txtCategory.text = arrayCategory[row]
        return arrayCategory[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        
        txtCategory.text = arrayCategory[row]
    }
    
    @IBAction func categoryAction(_ sender: UITextField)
    {
        arrayCategory = ["Cloth","Electronics","Furnitures","Games & Toys","Machines & Machinery","Office Items","Others","Sports & Fittness","Studies Items","Vehicals"]
        
        pickerView.delegate = self
        txtCategory.inputView = pickerView
        
        let toolBar =  UIToolbar()
        toolBar.sizeToFit()
        let flexibaleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: self, action: nil)
        let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(self.dismissKeybord))
        toolBar.setItems([flexibaleSpace,doneBtn], animated: false)
        txtCategory.inputAccessoryView = toolBar
    
        func DatePickerValueChanged(sender:UIDatePicker)
        {
            let dateFormatter = DateFormatter()
            dateFormatter.timeStyle = DateFormatter.Style.short
            dateFormatter.dateStyle = DateFormatter.Style.medium
            txtCategory.text = dateFormatter.string(from: sender.date)
        }
        
    }
    @IBAction func subCatAction(_ sender: UITextField)
    {
    }
    
    func getPostData()
    {
        
        let url  = URL(string: WebUrl.POST_URL)
        let headers = authenticaton.Authentication()
        
        let params = ["\(JsonFields.POST_TITLE)":"\(self.txtTitle.text!)","\(JsonFields.POST_DESC)":"\(self.txtDescription.text!)","\(JsonFields.POST_CATEGORY)":"\(self.txtCategory.text!)","\(JsonFields.POST_SUB_CAT)":"\(self.txtSubCategory.text!)","\(JsonFields.POST_QUANTITY)":"\(self.lblQuantity.text!)","\(JsonFields.POST_MOBILE)":"\(self.txtMobile.text!)","\(JsonFields.POST_CONDITION)":"\(self.txtProductCondition.text!)","\(JsonFields.POST_BRAND_NAME)":"\(self.txtBrandName.text!)","\(JsonFields.POST_RENT_AMOUNT)":"\(self.txtRentAmount.text!)","\(JsonFields.POST_SECURITY_AMOUNT)":"\(self.txtSecurityAmount.text!)"]
        
        Alamofire.request(url!,method: .post,parameters: params,headers: headers).responseJSON
            { response in
            
                if (response.result.error == nil)
                {
                    let result = response.result
                    
                    if let dict = result.value as? Dictionary<String,AnyObject>
                    {
                        
                        if let postTitle = dict["\(JsonFields.POST_TITLE)"]
                        {
                            self.arrayTitle = postTitle as! String
                        }
                        if let postDesc = dict["\(JsonFields.POST_DESC)"]
                        {
                            self.arrayDesc = postDesc as! String
                        }
                        if let postCat = dict["\(JsonFields.POST_CATEGORY)"]
                        {
                            self.arrayCategory = [postCat as! String]
                        }
                        if let postSubCat = dict["\(JsonFields.POST_SUB_CAT)"]
                        {
                            self.arraySubCat = [postSubCat as! String]
                        }
                        if let postQnty = dict["\(JsonFields.POST_QUANTITY)"]
                        {
                            self.arrayQuantity = postQnty as! String
                        }
                        if let postMobile = dict["\(JsonFields.POST_MOBILE)"]
                        {
                            self.arrayMobile = postMobile as! String
                        }
                        if let postCondition = dict["\(JsonFields.POST_CONDITION)"]
                        {
                            self.arrayCondition = [postCondition as! String]
                        }
                        if let postBrandName = dict["\(JsonFields.POST_BRAND_NAME)"]
                        {
                            self.arrayBrandName = postBrandName as! String
                        }
                        if let postRentAmount = dict["\(JsonFields.POST_RENT_AMOUNT)"]
                        {
                            self.arrayRentAmount = postRentAmount as! String
                        }
                        if let postDeposit = dict["\(JsonFields.POST_SECURITY_AMOUNT)"]
                        {
                            self.arraySecurityAmount = postDeposit as! String
                        }
                        self.arrayStatus = dict["\(JsonFields.POSR_STATUS)"] as! Int
                    }
                    
                    if self.arrayStatus == 1
                    {
                        self.view.makeToast("Product Posted Successfully", duration: 2.0, position: .center)
                        let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC")
                        self.present(dest, animated: true, completion: nil)
                    }
                    else if self.arrayStatus == 0
                    {
                        self.view.makeToast("Envalid Details", duration: 1.0, position: .bottom)
                        self.txtTitle.becomeFirstResponder()
                    }
                    
                }else{
                    print(response.result.error!)
                }
                
            }
        
    }
    
    @IBAction func btnPostDataAction(_ sender: UIButton)
    {
        if self.txtTitle.text == ""
        {
            let altError = UIAlertController(title: "RentPay", message: "Please Currect Details", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler:nil)
            altError.addAction(okAction)
            self.present(altError, animated: true, completion: nil)
            self.txtTitle.becomeFirstResponder()
            
        } else if self.txtDescription.text == ""
        {
            let altError = UIAlertController(title: "RentPay", message: "Please enter Description", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler:nil)
            altError.addAction(okAction)
            self.present(altError, animated: true, completion: nil)
            self.txtDescription.becomeFirstResponder()
            
        } else if self.txtMobile.text == ""
        {
            let altError = UIAlertController(title: "RentPay", message: "Please enter Mobile", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler:nil)
            altError.addAction(okAction)
            self.present(altError, animated: true, completion: nil)
            self.txtMobile.becomeFirstResponder()
        }
        else if txtTitle.text != "" && txtDescription.text != "" && txtCategory.text != "" && txtSubCategory.text != "" && txtMobile.text != "" && txtProductCondition.text != ""
            && txtBrandName.text != "" && txtRentAmount.text != "" && txtSecurityAmount.text != ""
        {
            let altError = UIAlertController(title: "RentPay", message: "Posted Successfully", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler:
            {
                (UIAlertAction) in
                //Call Post Data Function
                self.getPostData()
            })
            altError.addAction(okAction)
            self.present(altError, animated: true, completion: nil)
        }
        
    }
    
    @IBAction func btnBackAction(_ sender: UIBarButtonItem)
    {
        self.dismiss(animated: true, completion:nil);
        let main = UIStoryboard(name: "Main", bundle: nil)
        let home = main.instantiateViewController(withIdentifier: "HomeVC")
        
        //self.revealViewController().pushFrontViewController(home, animated: true)
        self.present(home, animated: true, completion: nil)
    }
    
}
