//
//  SignUPVC.swift
//  RentPayApp
//
//  Created by Akash Technolabs on 27/09/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit
import Alamofire

class SignUpVC: UIViewController,UITextFieldDelegate
{

    
    @IBOutlet weak var txtName: HoshiTextField!
    @IBOutlet weak var txtEmail: HoshiTextField!
    @IBOutlet weak var txtPassword: HoshiTextField!
    @IBOutlet weak var btnSignUp: UIButton!
    
    //FOR SIGNUP
    var authorization = ApiAuthorization()
    var userStatus = Int()
    var userName = String()
    var userEmail = String()
    var userPassword = String()
    

    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        

        let createRectShape = CAShapeLayer()
        createRectShape.bounds = btnSignUp.frame
        createRectShape.position = btnSignUp.center
        
        createRectShape.path = UIBezierPath(roundedRect: btnSignUp.bounds, byRoundingCorners: [UIRectCorner.bottomLeft , UIRectCorner.topRight], cornerRadii: CGSize(width: 5, height: 5)).cgPath
        btnSignUp.layer.mask = createRectShape
        
        // Do any additional setup after loading the view.
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        if textField == txtName
        {txtEmail.becomeFirstResponder()
        }
        else if textField == txtEmail
        {txtPassword.becomeFirstResponder()
        }
        return true
    }
    
    
    func textField()
    {
        let borderName = CALayer()
        let widthName = CGFloat(2.0)
        borderName.borderColor = UIColor(hexString: "#74BD0D").cgColor
        borderName.frame = CGRect(x: 0, y: txtName.frame.size.height - widthName, width:  txtName.frame.size.width, height: txtName.frame.size.height)
        
        borderName.borderWidth = widthName
        txtName.layer.addSublayer(borderName)
        txtName.layer.masksToBounds = true

        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor(hexString: "#74BD0D").cgColor
        border.frame = CGRect(x: 0, y: txtEmail.frame.size.height - width, width:  txtEmail.frame.size.width, height: txtEmail.frame.size.height)
        
        border.borderWidth = width
        txtEmail.layer.addSublayer(border)
        txtEmail.layer.masksToBounds = true
        
        let borderPassword = CALayer()
        let widthPassword = CGFloat(2.0)
        borderPassword.borderColor = UIColor(hexString: "#74BD0D").cgColor
        borderPassword.frame = CGRect(x: 0, y: txtPassword.frame.size.height - widthPassword, width:  txtPassword.frame.size.width, height: txtPassword.frame.size.height)
        
        borderPassword.borderWidth = widthPassword
        txtPassword.layer.addSublayer(borderPassword)
        txtPassword.layer.masksToBounds = true
        
        //For CreatAccount Button
        let createRectShape = CAShapeLayer()
        createRectShape.bounds = btnSignUp.frame
        createRectShape.position = btnSignUp.center
        
        createRectShape.path = UIBezierPath(roundedRect: btnSignUp.bounds, byRoundingCorners: [UIRectCorner.bottomLeft , UIRectCorner.topRight], cornerRadii: CGSize(width: 5, height: 5)).cgPath
        btnSignUp.layer.mask = createRectShape
        
    }
        
    @IBAction func btnBackAction(_ sender: Any)
    {
        
        let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignInVC")
        self.revealViewController().pushFrontViewController(dest, animated: true)
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnSignUpAction(_ sender: UIButton)
    {
        
        if self.txtName.text == ""
        {
        
            
            let altError = UIAlertController(title: "RentPay", message: "Please Currect Details", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler:nil)
            altError.addAction(okAction)
            self.present(altError, animated: true, completion: nil)
            self.txtName.becomeFirstResponder()
            
        } else if self.txtEmail.text == ""
        {
            let altError = UIAlertController(title: "RentPay", message: "Please enter Email", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler:nil)
            altError.addAction(okAction)
            self.present(altError, animated: true, completion: nil)
            self.txtName.becomeFirstResponder()
            
        } else if self.txtPassword.text == ""
        {
            let altError = UIAlertController(title: "RentPay", message: "Please enter Password", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler:nil)
            altError.addAction(okAction)
            self.present(altError, animated: true, completion: nil)
            self.txtPassword.becomeFirstResponder()
        }
         else if txtName.text != "" && txtEmail.text != "" && txtName.text != "" && txtPassword.text != ""
        {
            let altError = UIAlertController(title: "RentPay", message: "SignUp Successfully", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler:
            {
                (UIAlertAction) in
                //Call Post Data Function
                self.getSignUpData()

            })
            altError.addAction(okAction)
            self.present(altError, animated: true, completion: nil)
            
        }
        
        
        
    }
 
   func getSignUpData()
   {
    
    let url = URL(string: WebUrl.SIGNUP_URL)
    
    let params = ["\(JsonFields.USER_NAME)":"\(self.txtName.text!)",
                  "\(JsonFields.USER_EMAIL)":"\(self.txtEmail.text!)",
                  "\(JsonFields.USER_PASSWORD)":"\(self.txtPassword.text!)",
                  "\(JsonFields.USER_IP)":"192.168.1.104"]

    let headers = authorization.Authentication()
    
    Alamofire.request(url!,method : .post,parameters: params,headers : headers).responseJSON { response in
        
        
        if (response.result.error == nil)
        {
            // print(response.result.value!)
            
            let result = response.result
            //Set json array in Record Array
            if let dict = result.value as? Dictionary<String,AnyObject>
            {
                
                if let regName = dict["\(JsonFields.USER_NAME)"]
                {
                    self.userName = regName as! String
                }
                
                if let regEmail = dict["\(JsonFields.USER_EMAIL)"]
                {
                    self.userEmail = regEmail as! String
                }
                
                if let regPass = dict["\(JsonFields.USER_PASSWORD)"]
                {
                    self.userPassword = regPass as! String
                }
                
                self.userStatus = dict["\(JsonFields.USER_STATUS)"] as! Int
            }
            if self.userStatus == 1
            {
                
                self.view.makeToast("Registration Success", duration: 2.0, position: .center)
                
                let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignInVC")
                self.present(dest, animated: true, completion: nil)
                
                
            } else if self.userStatus == 0 {
                
                self.view.makeToast("Already Registered", duration: 1.0, position: .bottom)
                self.txtEmail.becomeFirstResponder()
            }
            
        }else{
            print(response.result.error!)
        }

        
    }

   }
}

