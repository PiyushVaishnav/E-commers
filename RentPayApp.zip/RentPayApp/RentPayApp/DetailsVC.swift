//
//  DetailsVC.swift
//  RentPayApp
//
//  Created by Akash Technolabs on 03/10/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit
import Alamofire
class DetailsVC: UIViewController, UITableViewDelegate, UITableViewDataSource
{

    @IBOutlet weak var detailTableView: UITableView!
    
    var backId = [String]()
    
    var cat_id = String()
    
    
    //ARRAY OBJECT FOR THE SET THE JSON
    var arrayCategoryListContent = [AnyObject]()
    var arrayCategoryListStatus = Int()
    
    var arrayCategoryList = [String]()
    var arrayCategoryListId = [String]()
    var arrayCategoryListName = [String]()
    var arrayCategoryListDesc = [String]()
    var arrayCategoryListRent = [String]()
    
    var arrayCategoryListImage = [AnyObject]()
    var arrayCategoryListImagaUrl = [String]()
    var innerStatus = 0
    
    var arrayProductImageUrl = [String]()
    // for the authentication
    var authenticaion = ApiAuthorization()
    var listCatID = String()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.getProductData()
        self.detailTableView.reloadData()
        self.detailTableView.tableFooterView = UIView()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {return arrayCategoryListName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailCell", for: indexPath) as! DetailViewCell
        //cell.uiView.layer.cornerRadius = cell.uiView.frame.height / 2
        let index = indexPath.row
        
        cell.lblTitle.text = arrayCategoryListName[index]
        cell.lblPrice.text = arrayCategoryListRent[index]
        
        //for the removing html tag into strin
        print("DESC_COUNT - \(arrayCategoryListDesc.count)")
        print("INDEXPATH - \(index)")
        //print("DESCRIPTION\(self.arrayCategoryListDesc[index])")
       //cell.lblDetails.text = arrayCategoryListDesc[index]
        
       
        let summary = "\(arrayCategoryListDesc[indexPath.row])"
        let str = summary.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
        print("string\(str)")
        cell.lblDetails.text = str
        //let content = arrayCategoryListDesc
        //arrayCategoryListDesc = content.replacingOccurrences(of: "<[^>]+>", with: "", options: String.CompareOptions.regularExpression, range: nil)
        

        
        if let imageUrl = URL(string: (arrayProductImageUrl[indexPath.row]))
        {
            print("image data",imageUrl)
            
            if let data =  NSData(contentsOf: imageUrl)
            {
                if data != nil
                {
                    cell.detail_ImageView.image = UIImage(data: data as Data)
                    //cell.detail_ImageView.layer.cornerRadius = cell.detail_ImageView.frame.height / 2
                    
                }
                else{print("error in imageview")}
            }
        }
        
        return cell
    }
    
    
    func getProductData()
    {
        let url = URL(string: WebUrl.CATEGORY_DETAIL_URL)
        let params = ["cat_id":"\(self.cat_id)"]
        let headers = authenticaion.Authentication()
        
        
        print(params)
        Alamofire.request(url!, method: .post, parameters: params, headers: headers).responseJSON
            {
                response in
                
                if (response.result.error == nil)
                {
                    let result = response.result
                    print("Result\(result)")
                    if let dict = result.value as? Dictionary<String,AnyObject>
                    {
                        self.innerStatus = dict["\(JsonFields.CATEGORY_DETAIL_STATUS)"] as! Int
                
                        print(self.innerStatus)
                        if self.innerStatus == 1
                        {
                            self.detailTableView.isHidden = false
                            
                            
                            if let innerDict = dict["\(JsonFields.CATEGORY_DETAIL_ARRAY)"]
                            {
                                print("Result1 : \(innerDict)")
                                self.arrayCategoryListContent = innerDict as! [AnyObject]
                            }
                            
                            for index in 0..<self.arrayCategoryListContent.count
                            {
                                let data = self.arrayCategoryListContent[index]
                                
                                print("Result3 : \(data)")
                                self.arrayCategoryListId.append(data["\(JsonFields.CATEGORY_DETAIL_ID)"] as! String)
                                self.arrayCategoryListName.append(data["\(JsonFields.CATEGORY_DETAIL_NAME)"] as! String)
                                self.arrayCategoryListDesc.append(data["\(JsonFields.CATEGORY_DETAIL_DESCRIPTION)"] as! String)
                                
                                
                                self.arrayCategoryListRent.append(data["\(JsonFields.CATEGORY_DETAIL_RENT)"] as! String)
                                
                                
                                if let innerImageDict = data["\(JsonFields.CATEGORY_DETAIL_IMAGE_ARRAY)"]
                                {
                                    //print("ImageURL : \(innerImageDict)")
                                    self.arrayCategoryListImage = innerImageDict as! [AnyObject]
                                
                                    if self.arrayCategoryListImage.count > 0
                                    {
                                        for image in 0..<self.arrayCategoryListImage.count
                                        {
                                            
                                            let imageData = self.arrayCategoryListImage[image]
                                            print("ImageURL \(imageData["\(JsonFields.CATEGORY_DETAIL_IMAGE)"])")
                                            self.arrayProductImageUrl.append("\(WebUrl.PRODUCT_THUMB_URL)\(imageData["\(JsonFields.CATEGORY_DETAIL_IMAGE)"] as! String )")
                                        }
                                    }
                                }
                                
                            }
                        }
                        else
                        {
                             let childViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "NoProduct")
                               self.addChildViewController(childViewController)
                           
                              self.view.addSubview(childViewController.view)
                              childViewController.didMove(toParentViewController: self)
                            
                        }
                        print("category id := \(self.arrayCategoryListId)")
                        print(self.arrayCategoryListName)
                        self.detailTableView.reloadData()
                    }
                    
                }
                else{print(response.result.error!)}
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let subCat = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DescriptionVC") as! DescriptionVC
        
        //subCat.back_id = "\(self.arrayCategoryListId)"
        subCat.back_id = "\(self.arrayCategoryListId[indexPath.row])"
        subCat.cat_id1 = "\(self.cat_id)"
        print("Category ID : \(cat_id)")
        self.present(subCat, animated: true, completion: nil)
    }
    

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func btnViewDetailsAction(_ sender: UIButton)
    {
        
        let subCat = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DescriptionVC") as! DescriptionVC
        
        //subCat.back_id = "\(self.arrayCategoryListId)"
        subCat.back_id = "\(self.arrayCategoryListId[0])"
        subCat.cat_id1 = "\(self.cat_id)"
        print("Category ID : \(cat_id)")
        self.dismiss(animated: true, completion:nil);
        //self.present(subCat, animated: true, completion: nil)
        
    }
    
    
    @IBAction func btnBackAction(_ sender: UIBarButtonItem)
    {
        self.dismiss(animated: true, completion:nil);
        let dest = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC")
        //self.revealViewController().pushFrontViewController(dest, animated: true)

        self.present(dest, animated: true, completion: nil)
    }

}
