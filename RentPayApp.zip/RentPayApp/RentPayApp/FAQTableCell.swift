//
//  FAQTableCell.swift
//  RentPayApp
//
//  Created by Akash Technolabs on 03/10/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit

class FAQTableCell: UITableViewCell
{

    
    @IBOutlet weak var lblIndex: UILabel!
    @IBOutlet weak var lblQuestion: UILabel!
    @IBOutlet weak var txtAnswer: UITextView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
