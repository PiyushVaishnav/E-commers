//
//  CheckConnectionVC.swift
//  RentPayApp
//
//  Created by Akash Technolabs on 27/09/17.
//  Copyright © 2017 AkashMacMini. All rights reserved.
//

import UIKit
extension UIColor
{
    convenience init(hexString: String) {
        let hex = hexString.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int = UInt32()
        Scanner(string: hex).scanHexInt32(&int)
        let a, r, g, b: UInt32
        switch hex.characters.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(red: CGFloat(r) / 255, green: CGFloat(g) / 255, blue: CGFloat(b) / 255, alpha: CGFloat(a) / 255)
    }
}


class CheckConnectionVC: UIViewController
{

    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var noInternetConnView: UIView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.noInternetConnView.isHidden = true
        activityIndicator.startAnimating()
        activityIndicator.isHidden = false
        self.perform(#selector(self.hideActivityIndicatior), with: nil, afterDelay: 3.0)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnRetryAction(_ sender: UIButton)
    {
        self.activityIndicator.isHidden = false
        self.activityIndicator.startAnimating()
        self.noInternetConnView.isHidden = true
        self.perform(#selector(self.hideActivityIndicatior), with: nil, afterDelay: 5.0)
        
    }

    func hideActivityIndicatior()
    {
        self.activityIndicator.stopAnimating()
        self.activityIndicator.hidesWhenStopped = true
        self.checkReachability()
        
    }
    
    func checkReachability()
    {
        if currentReachabilityStatus == .reachableViaWiFi
        {
            print("User is Connected via WIFI")
            self.goToHome()
        }
        else if currentReachabilityStatus == .reachableVieWWAN
        {
            print("User is Connected via WAN")
            self.goToHome()
        }
        else if currentReachabilityStatus == .notReachable
        {
            print("There is no Internet Connection")
             self.noInternetConnView.isHidden = false
        }
    
    }
    
    func goToHome()
    {
        let home = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC")
        self.present(home, animated: true, completion: nil)
    }

}
