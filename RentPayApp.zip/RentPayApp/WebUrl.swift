//
//  WebUrl.swift
//  Quotes And Status
//
//  Created by Akash Padhiyar on 7/14/17.
//  Copyright © 2017 com.awesomeinfotech. All rights reserved.
//

import Foundation
class WebUrl
{
    //Common
    static var MAIN_URL = "http://moneyportal.in/app/"
    
    static var PRODUCT_IMAGE_URL = "http://moneyportal.in/images/product/"
    static var PRODUCT_THUMB_URL = "http://moneyportal.in/images/product/thumb/"
   
    //Slider
    static var SLIDER_URL = MAIN_URL + "slider"
    static var SLIDER_IMAGE_URL = "http://moneyportal.in/images/slider/"
    
    //CATEGORY_LIST_URL
    static var CATEGORY_LIST = MAIN_URL + "category-list"
    
    //CATEGORU_LIST_IMAGES
    static var CATEGORY_IMAGE_URL = "http://moneyportal.in/images/category/"
    
    //SIGN_UP URL
    static var SIGNUP_URL = MAIN_URL + "user-signup"
    
    //SIGN_IN URL
    static var SIGNIN_URL = MAIN_URL + "user-login"

    //FAQ URL
    static var FAQ_URL = MAIN_URL + "faq"
    
    //PRODUCT DETAILS
    static var CATEGORY_DETAIL_URL = MAIN_URL + "product-list"
    
    //PRODUCT DESCRIPTIONS
    static var DESCRIPTIONS_URL = MAIN_URL + "product-details"
    
    //POST FIELDS
    static var POST_URL = MAIN_URL + "user-add-product"
    
}
